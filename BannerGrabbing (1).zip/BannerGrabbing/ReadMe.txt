READ ME: 
Run the code on any python 3 supporting platform. 

To run the code : python3 bannergrab.py 

On successful run, the code will run as follows:

Enter IP or URL : www.google.com
Enter port : 80

-----------Displays masked banner information-----------

To unmask and understand, you need an Username and Password


Do you want to continue?
 1.YES
 2.NO

1


Enter Username : malware
Enter Password:                         # password is 'Malware'       

-----------Displays unmasked banner information----------


Incase username and pasword are incorrect, the program will exit. 